<?php
class Crud extends CI_Controller {

	function __construct()
	{
	  parent::__construct();
		$this->load->model('select');
	}
	public function index()
	{

		$this->load->view('example');

	}
public function checking()
{
	//insert Operation
	 print_r($_POST);
	$this->select->model_function($_POST);



}

public function selecting()
{
$data=$this->select->model_select();

$result=$data->result();
print_r($result);




}






}
?>
