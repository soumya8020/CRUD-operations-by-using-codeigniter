<!DOCTYPE html>
<html>
<head>
	<title>CRUD Operations in codeigniter</title>
</head>
<style>
form{
  border:1px solid black;
  width:35%;
   border-radius: 25px;
   margin-top:10%;
}
body{
  background-color: #fbedea;
}
</style>
<body>
  <center>

<form action="" method="get">
  <br>
    <h2>Signup Page</h2>
	<label>Firstname:</label><input type="text" name="fname" placeholder="Enter Firstname" required>
	<br><br>
	<label>Lastname:</label><input type="text" name="lname" placeholder="Enter Lastname" required>
	<br><br>
	<label>Email_id:</label><input type="email" name="email" placeholder="Enter Mail_ID" required>
	<br><br>
	<label>Phone_No:</label><input type="text" name="mno" placeholder="Enter Phone_No" required>
	<br><br>
	<label>Password:</label><input type="password" name="pass" placeholder="Enter Password" required>
	<br><br>
	<input type="submit" value="Submit" data-toggle="tooltip" title="Click here">
  <br><br>
</form>

</center>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
</body>
</html>
