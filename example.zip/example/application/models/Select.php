<?php


class Select extends CI_Model {

  public function __construct(){
		parent::__construct();
		 // $this->load->database();
	}
function model_function($arrForm){

$this->db->insert('ex', $arrForm);

}

function model_select()
{
  $sql = "select * from ex";
  $query = $this->db->query($sql);
return $query;



}


}
?>
